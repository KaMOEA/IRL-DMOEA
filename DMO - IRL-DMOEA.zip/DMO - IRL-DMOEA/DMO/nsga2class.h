#ifndef __INDIVIDUAL__H_
#define __INDIVIDUAL__H_

#include "global.h"
#include "objective.h"
#include "benchmark.h"

class CNSGA2Ind{
public:
    vector <double> x_var;
	vector <double> y_obj;
	vector <double> yj;

    int    rank, count;

    void   rnd_init();
    void   obj_eval();
    void   show_objective();
	void   rnd_init1(double T);
	void   obj_eval1(double T);

    CNSGA2Ind();
	~CNSGA2Ind();

    bool   operator<(const CNSGA2Ind& ind2);
    bool   operator==(const CNSGA2Ind& ind2);
    void   operator=(const CNSGA2Ind& ind2);
};

CNSGA2Ind::CNSGA2Ind()
{

	for(int i=0; i<nvar; i++)
		x_var.push_back(0.0);
	for(int j=0; j<nobj; j++)
	    y_obj.push_back(0.0);
	rank    = 0;
    for(int i=0; i<nvar; i++)
		yj.push_back(0.0);
}

CNSGA2Ind::~CNSGA2Ind()
{
    x_var.clear();
	y_obj.clear();
    yj.clear();
}

void CNSGA2Ind::rnd_init()
{
	lowBound=0;uppBound=1;//0
	/*for(int i=1;i<nvar;i++)
	{
       lowBound[i]=-1;uppBound[i]=1;
	}*/
    for(int n=0;n<nvar;n++)
	{
		x_var[n] = lowBound + rnd_uni(&rnd_uni_init)*(uppBound - lowBound);

	}
    obj_eval();
}
void CNSGA2Ind::rnd_init1(double T)
{
	lowBound=0;uppBound=1;//0
	/*for(int i=1;i<nvar;i++)
	{
       lowBound[i]=-1;uppBound[i]=1;
	}*/
   
    for(int n=0;n<nvar;n++)//0
	{
		x_var[n] = lowBound + rnd_uni(&rnd_uni_init)*(uppBound - lowBound);

	}
    obj_eval1(T);
}

void CNSGA2Ind::obj_eval()
{
	
	benchmark(x_var,y_obj);	
	

	//objective(x_var,y_obj);		
}
void CNSGA2Ind::obj_eval1(double T)
{
	benchmark1(x_var,y_obj, T);	
	//benchmark2(x_var,y_obj, T);
    //benchmark3(x_var,y_obj, T,yj);
    //benchmark4(x_var,y_obj, T,yj);
	//benchmark5(x_var,y_obj, T,yj);
    //benchmark6(x_var,y_obj,T);
	//benchmark7(x_var,y_obj, T,yj);
	//benchmark8(x_var,y_obj, T,yj);
	//benchmark9(x_var,y_obj, T);
	//benchmark10(x_var,y_obj, T);
	//benchmark11(x_var,y_obj, T);
	//benchmark12(x_var,y_obj, T);
	
		
}

void CNSGA2Ind::show_objective()
{

	for(int n=0;n<nobj;n++)
		std::cout<<y_obj[n]<<" ";
	std::cout<<rank<<" ";
	std::cout<<"\n";

}


bool CNSGA2Ind::operator<(const CNSGA2Ind& ind2)
{
	int flag2 = 0;
	for(int n=0;n<nobj;n++)
	{
	    if(ind2.y_obj[n] < y_obj[n])
	        return false;
		if(ind2.y_obj[n] == y_obj[n])
			flag2++;
    }

    if(flag2==nobj) return false;

	return true;
}

bool CNSGA2Ind::operator==(const CNSGA2Ind& ind2)
{
	int flag = 0;
	for(int n=0;n<nobj;n++)
	{
	    if(ind2.y_obj[n] !=y_obj[n])
	        return false;
    }
    return true;
}

void CNSGA2Ind::operator=(const CNSGA2Ind& ind2)
{
	for(int n=0;n<nobj;n++)
	    y_obj[n] = ind2.y_obj[n];

	for(int n=0;n<nvar;n++)
	    x_var[n] = ind2.x_var[n];
    rank  = ind2.rank;
}

#endif