#ifndef __CNSGA2CLASS_H_
#define __CNSGA2CLASS_H_

#include "global.h"
#include "recombination.h"
#include "common.h"
#include "nsga2class.h"
#include <algorithm>
#include <numeric>
#include <functional>

#define pi 3.1415926
double T;



class CNSGA2    
{
public:
	CNSGA2();
	virtual ~CNSGA2();

	vector<double> execute(int run);
	void init_population();
	double calc_distance();
	int  tour_selection();
	void fill_union(CNSGA2Ind &ind);
	void rank_popu();
	void eval_dens();
	void initial(double T);
	void save_front(char saveFilename[1024]);                              // save the pareto front into files
	void save_ps(char savefilename[1024]);
	double calc_hv();
	double execute_RL();
	
	void preserveigd();
	void preservehv();

	
	void eval_dens1();
	void dens2();
	void change(double T);
	void change1(double T);
	void change2(double T);

	void detectchange(double T);
	void init_values();
	void select(double T,double et);
	void modeltraining();
	double random_pick_policy();
	double expert_policy();

	void selecttest(double T,double et);
    void hv();



	double calc_distancetext();
  


    vector <CNSGA2Ind>  population;    
	vector <CNSGA2Ind>  ps;
	vector <CNSGA2Ind>  offspring;

   vector <CNSGA2Ind>  spopulation;
   vector <CNSGA2Ind> Q; 
	double distance;

	int    nfes;

	vector<CNSGA2Ind>  Q0, Q1; 
    vector<CNSGA2Ind>  Q2; 
    vector<CNSGA2Ind>  CC;
    vector<CNSGA2Ind>  C0, C1,C2;
	vector <CNSGA2Ind>  archive;
    vector <CNSGA2Ind>  ps11;
	vector <CNSGA2Ind>  ps1;


    vector<CNSGA2Ind>  L;
	vector<int> experts;
    vector<int> experta;
	vector<double> reward_list;
    void operator=(const CNSGA2 &alg);
};

CNSGA2::CNSGA2(){

}

CNSGA2::~CNSGA2(){

}

void CNSGA2::operator=(const CNSGA2 &alg)
{
	population = alg.population;
	offspring  = alg.offspring;
	ps         = alg.ps;
	nfes       = alg.nfes;
	distance   = alg.distance;
	spopulation =alg.spopulation;
	Q          =alg.Q;
}

void CNSGA2::init_population()
{

	for(int n=0;n<pops;n++)
	{
		CNSGA2Ind ind;
		ind.rnd_init();
		population.push_back(ind);
		spopulation.push_back(ind);
		nfes++;
	}
	//detectors = (int) (0.1*pops);
	

}

int  CNSGA2::tour_selection()
{
	int p1 = int(rnd_uni(&rnd_uni_init)*pops);
	int p2 = int(rnd_uni(&rnd_uni_init)*pops);

	if(population[p1].rank<population[p2].rank)
		return p1;
	else
		return p2;
}


void CNSGA2::fill_union(CNSGA2Ind &ind)
{
    bool flag = true;
	int  size = offspring.size();
	for(int i=0; i<size; i++){
		if(ind==offspring[i]){
            flag = false;
			break;
		}
	}
	if(flag) offspring.push_back(ind);
}

void CNSGA2::initial(double T)
{
    for(int n=0; n<pops; n++)
	{
		int p1, p2, p3;        
		p1 = tour_selection();
		while(1){  p2 = tour_selection();  	if(p2!=p1) break; }
		while(1){  p3 = tour_selection();  	if(p3!=p1&&p3!=p2) break; }
		CNSGA2Ind child;
		diff_evo_xover2(population[p1],population[p2],population[p3],child);
		//realmutation(child, 1.0/nvar);
		child.obj_eval1(T);

        fill_union(child);
		fill_union(population[n]);

		nfes++;
	}
}

void CNSGA2::rank_popu()
{
	int size = offspring.size();
	int** cset;  

	int* rank = new int[size];

	cset = new int*[size];

    for(int i=0; i<size; i++) 
        cset[i] = new int[size];

    for(int i=0; i<size; i++) 
	{
		rank[i]  = 0;
		offspring[i].rank  = -1;
		offspring[i].count = 0;

	}
/****************///original
	for(int k=0; k<size; k++)
	    for(int j=0; j<size; j++)
		{
			if(k!=j)
			{
				if((offspring[j]<offspring[k])&&!(offspring[j]==offspring[k])) 
				 rank[k]++;
                
				if((offspring[k]<offspring[j])&&!(offspring[j]==offspring[k]))
				{
					offspring[k].count++;
					int m = offspring[k].count - 1;
					cset[k][m] = j;
				}
			}
		}
	/**************/
	/*for(int k=0; k<size; k++)
	{
	    for(int j=0; j<size; j++)
		{
			if(k!=j)
			{
				if(offspring[j].y_obj[0]<offspring[k].y_obj[0])
				{
					if(offspring[j].y_obj[1]<offspring[k].y_obj[1])
					{rank[k]++;
					}
					
				
				}
                
				if(offspring[k].y_obj[0]<offspring[j].y_obj[0])
				{
					if(offspring[k].y_obj[1]<offspring[j].y_obj[1])
					{offspring[k].count++;
					int m = offspring[k].count - 1;
					cset[k][m] = j;

					}
					
				}
			}
		}
	}*/
    
	int curr_rank = 0;
	while(1)
	{
		int stop_count = 0;
		int* rank2 = new int[size];
	    for(int k=0; k<size; k++)
			rank2[k] = rank[k];

        for(int k=0; k<size; k++)
		{			
		    if((offspring[k].rank==-1)&&(rank[k]==0))
			{
			    offspring[k].rank = curr_rank;
				for(int j=0; j<offspring[k].count; j++)
				{
				   int id =	cset[k][j];
				   rank2[id]--;
				   stop_count++;
				}
			}						
		}

	    for(int k=0; k<size; k++)
			rank[k] = rank2[k];

        delete [] rank2;
		curr_rank++;
		if(stop_count==0) break;
	}

    delete [] rank;

    for(int i=0; i<size; i++) 
        delete cset[i];
	delete[] cset;
}

void CNSGA2::eval_dens()
{
    //Q.clear();
    archive.clear();//
	population.clear();
	ps.clear();//
	//int *rran=new int[200];
	int size = offspring.size();
	int rank = 0;

	
	while(1){
		int count = 0;
        for(int i=0; i<size; i++)
			if(offspring[i].rank==rank)
				count++;

       

		int size2 = population.size() + count;
		if(size2>pops) {
			break;
		}

        for(int i=0; i<size; i++)
  	        if(offspring[i].rank==rank)
			    population.push_back(offspring[i]);
		rank++;
		if(population.size()>=pops) break;
	}

	if(population.size()<pops){
	    vector<CNSGA2Ind> list;
		// save the individuals in the overflowed front
        for(int i=0; i<size; i++)
  	        if(offspring[i].rank==rank)
		        list.push_back(offspring[i]);
		for(int i=0;i<offspring.size();i++)/////
		{
             if(offspring[i].rank==rank)
			 {archive.push_back(offspring[i]);}
		}
		int s2 = list.size();
		double *density = new double[s2];
		int    *idx     = new int[s2];
		/*for(int i=0; i<list.size(); i++)
		{
			for(int k=0;k<nobj;k++)
			{
				cout<<list[i].y_obj[k]<<"  ";
				cout<<"\n";
			 }
		}
		cout<<"********************"<<endl;*/
     	
		for(int i=0; i<s2; i++){
			idx[i]     = i;
			density[i] = 0;
		}

		int    *idd     = new int[s2];
		double *obj     = new double[s2];
		for(int j=0; j<nobj; j++){		    			
			for(int i=0; i<s2; i++){
			    idd[i] = i;
				obj[i] = list[i].y_obj[j];
			}
			minfastsort(obj,idd,s2,s2);
            density[idd[0]]    += -1.0e+30;
            density[idd[s2-1]] += -1.0e+30;
			for(int k=1; k<s2-1; k++)
				density[idd[k]]+= -(obj[k] - obj[k-1] + obj[k+1] - obj[k]);
           

		}
		delete [] idd;
		delete [] obj;

		int s3 = pops - population.size();

		minfastsort(density,idx,s2,s3);
		
		for(int i=0; i<s3; i++)
		{
            //if((list[idx[i]].y_obj[0]<=2)&&(list[idx[i]].y_obj[1]<=2))
			population.push_back(list[idx[i]]);

		}
         /*for (int i=0; i< Q2.size(); i++)
	    {
           population.push_back(Q2[i]);
	    }*/
		delete [] density;
		delete [] idx;
	}

	offspring.clear();

	
	for(int k=0; k<archive.size(); k++)
	{
         //if((archive[k].rank==0)&&(archive[k].y_obj[1]<=2))
		 //if(archive[k].rank==0)
			{ps.push_back(archive[k]);}
			
		

	}
	

}
void CNSGA2::eval_dens1()//
{
    //population.clear();
    spopulation.clear();
	
	Q.clear();
	int size = offspring.size();
	int rank = 0;
	//while(1)
	//{
	//	int count = 0;
 //       for(int i=0; i<size; i++)
	//		if(offspring[i].rank==rank)
	//			count++;
	//	/*int size2 = population.size() + count;
	//	if(size2>pops) {
	//		break;
	//	}*/

	//	for(int i=0; i<size; i++)
 // 	        if(offspring[i].rank==rank)
	//            population.push_back(offspring[i]);
	//	      rank++;
	//	if(population.size()>=pops) 
	//		break;
	//}
	for(int i=0; i< 100;i++)
	{
		if(population[i].rank==0)
           spopulation.push_back(population[i]);
	}
    
	int a=1;
	int s2=spopulation.size();
	int s4=100;
	
	double *density = new double[s2];
	int    *idx     = new int[s2];

	double *density1 = new double[s4];
	int    *idx1     = new int[s4];

	

	for(int i=0; i<s2; i++){
		idx[i]     = i;
		density[i] = 0;
	}

	for(int i=0; i<s4; i++){
			idx1[i]     = i;
			density1[i] = 0;//afmin
		}
	int    *idd     = new int[s2];
	double *obj     = new double[s2];


	int    *idd1     = new int[s4];
	double *obj1     = new double[s4];


	for(int j=0; j<nobj; j++)
	{		    			
		for(int i=0; i<s2; i++)
		{
		    idd[i] = i;
			obj[i] = spopulation[i].y_obj[j];
		}
		minfastsort(obj,idd,s2,s2);
		vector <CNSGA2Ind> list;
		for(int k=0; k<s2; k++)
		{
			list.push_back(spopulation[idd[k]]);
		}
		double min= list[0].y_obj[j];
		double max= list[s2-1].y_obj[j];
		density[idd[0]]    += -1.0e+30;
		density[idd[s2-1]] += -1.0e+30;
		for(int k=0; k<s2; k++)
		{
				density[idd[k]]+= (obj[k] - min)/ ( max - min);//-(obj[k] - obj[k-1] + obj[k+1] - obj[k])
		        //density[idd[k]]=abs(density[idd[k]]);
		}
		int a=1;
	}	/*delete [] idd;
		delete [] obj;*/
     
	for(int j=0; j<nobj; j++)
	{
        for(int i=0; i<s2; i++)
		{
		    idd[i] = i;
			obj[i] += spopulation[i].y_obj[j];
		}
	}
	minfastsort(obj,idd,s2,s2);

	    int s3 = spopulation.size();
        vector<CNSGA2Ind> kneelist;
		//minfastsort(density,idx,s2,s3);

		for(int i=0; i<s3; i++)
		{
		
			//kneelist.push_back(spopulation[idx[i]]);//
            kneelist.push_back(spopulation[idd[i]]);
		}
		
		Q.push_back(kneelist[0]);
		int z=1;


		

		/*delete [] density1;
		delete [] idx1*/;
		int dd=1;

	//}
	

	/*population.clear();
	int aa=1;
	for(int i=0; i< Q.size();i++)
	{		
		population.push_back(Q[i]);
	}*/

	Q0.clear();
	for(int j=0; j< Q.size();j++)
	{		
		Q0.push_back(Q[j]);
	}

	CC.clear();
    for(int k=0; k< Q.size();k++)
	{		
		CC.push_back(Q[k]);
	}
	for (int n = 0; n < nvar; n++)
	{
	   for (int z=0;z<population.size();z++)
	   
          CC[0].x_var[n] += population[z].x_var[n];
		  CC[0].x_var[n] /= population.size();

	}
	for (int m=0;m<nobj;m++)
	{
        CC[0].y_obj[m]=0;
	}
	C0.clear();
	C0=CC;


    delete [] idd;
	delete [] obj;
	delete [] idd1;
	delete [] obj1;
	delete [] density;
	delete [] idx;
	delete [] density1;
	delete [] idx1;
	
	
	offspring.clear();
	
}

void CNSGA2::dens2()
{
    //population.clear();
    spopulation.clear();
	
	Q.clear();

	for(int i=0; i< 100;i++)
	{
		if(population[i].rank==0)
           spopulation.push_back(population[i]);
	}
    
	int a=1;
	int s2=spopulation.size();
	int s4=100;
	
	double *density = new double[s2];
	int    *idx     = new int[s2];

	double *density1 = new double[s4];
	int    *idx1     = new int[s4];

	

	for(int i=0; i<s2; i++){
		idx[i]     = i;
		density[i] = 0;
	}

	for(int i=0; i<s4; i++){
			idx1[i]     = i;
			density1[i] = 0;//afmin
		}
	int    *idd     = new int[s2];
	double *obj     = new double[s2];


	int    *idd1     = new int[s4];
	double *obj1     = new double[s4];


	for(int j=0; j<nobj; j++)
	{		    			
		for(int i=0; i<s2; i++)
		{
		    idd[i] = i;
			obj[i] = spopulation[i].y_obj[j];
		}
		minfastsort(obj,idd,s2,s2);
		vector <CNSGA2Ind> list;
		for(int k=0; k<s2; k++)
		{
			list.push_back(spopulation[idd[k]]);
		}
		double min= list[0].y_obj[j];
		double max= list[s2-1].y_obj[j];
		density[idd[0]]    += -1.0e+30;
		density[idd[s2-1]] += -1.0e+30;
		for(int k=0; k<s2; k++)
		{
				density[idd[k]]+= (obj[k] - min)/ ( max - min);
		        //density[idd[k]]=abs(density[idd[k]]);
		}
		int a=1;
		
	}

	for(int j=0; j<nobj; j++)
	{
        for(int i=0; i<s2; i++)
		{
		    idd[i] = i;
			obj[i] += spopulation[i].y_obj[j];
		}
	}
	 minfastsort(obj,idd,s2,s2);

	    int s3 = spopulation.size();
        vector<CNSGA2Ind> kneelist;
		//minfastsort(density,idx,s2,s3);

		for(int i=0; i<s3; i++)
		{
		
			//kneelist.push_back(spopulation[idx[i]]);//
            kneelist.push_back(spopulation[idd[i]]);
		}
		
		Q.push_back(kneelist[0]);
		int z=1;
		

		/*delete [] density1;
		delete [] idx1*/;
		int dd=1;

	//}
	
	Q1.clear();
	for(int j=0; j< Q.size();j++)
	{		
		Q1.push_back(Q[j]);
	}

  

    delete [] idd;
	delete [] obj;
	delete [] idd1;
	delete [] obj1;
	delete [] density;
	delete [] idx;
	delete [] density1;
	delete [] idx1;
	
	
	offspring.clear();
	
}

void CNSGA2::change(double T)//
{
	//initial(t);
	//rank_popu();
	dens2();
	Q2.clear();
	int size = 20;
	double stepsize = 1.0;
	int a=T;
	//if (Q0.size()) stepsize = dist_vector(Q0, Q1);
    vector<double>  C(nvar, 0);
	vector<CNSGA2Ind> predict;
	vector <double> C2(nvar, 0); 
	
	for (int n = 0; n < nvar; n++)
	{
		for (int i = 0; i < Q0.size(); i++)
			C[n] += Q0[i].x_var[n];
		C[n] /= Q0.size();

		for (int i = 0; i < Q1.size(); i++)
			C2[n] += Q1[i].x_var[n];
		C2[n] /= Q1.size();
	}
   for(int i=0; i<Q1.size();i++)
	{
		/*for (int n = 0; n < nvar; n++)
		{*/
			Q2.push_back(Q1[i]);
		/*}*/
	}
	/*for (int i = 0; i < predict.size(); i++)
	{
		if (Q0.size())
			for (int n = 0; n < nvar; n++)
			{
				double normd = dist_vector(C, C2);
				normd = normd>0 ? normd : 1.0e-6;
				population[predict[i]].x_var[n] += stepsize*(C[n] - C2[n]) / normd + rnd_gaussian(&rnd_uni_init, 0, stepsize /2);
			}
		population[predict[i]].obj_eval1(T);
	}*/
	for (int i = 0; i < population.size(); i++)
	{
		if (Q1.size())
			for (int n = 0; n < nvar; n++)
			{
				/*for(int j=0; j<nobj; j++)
			   { */ 
				double normd = dist_vector(C, C2);
				normd = normd>0 ? normd : 1.0e-6;
				
				population[i].x_var[n]= fabs( population[i].x_var[n]+ stepsize*(C[n] - C2[n])*normd  + rnd_gaussian(&rnd_uni_init, 0, stepsize /2));/// normd
                if (population[i].x_var[n]<lowBound) population[i].x_var[n] = lowBound;
				if (population[i].x_var[n]>uppBound) population[i].x_var[n] = uppBound;
				population[i].rnd_init1(a);
				//int a=1;
				/*}*/
			}
			//int a=1;
			population[i].obj_eval1(T);
			//predict.push_back(Q2[i]);

		
	}

	 char filenamechange[1024];
   for(int gen=1; gen<=max_gen1; gen++)
 {
   initial(a);
   rank_popu();
   eval_dens();
   sprintf(filenamechange,"F:\\gen\\%fdynamic_%d.txt",T, gen);
   
   ofstream filechange(filenamechange);
   for(int n=0; n<pops; n++)
  {
	
	//filex<<population[n].y_obj[0]<<"  "<<" "<<population[n].y_obj[1]<<"  "<<" "<<population[n].y_obj[2]<<endl;
	filechange<<population[n].y_obj[0]<<"  "<<" "<<population[n].y_obj[1]<<endl;    

   }
   calc_distancetext();
 }
  
	
	Q0 = Q1;
    Q1 = Q2;
	
	offspring.clear();
	int k=1;

}


void CNSGA2::change2(double T)//
{
	double a=T;
	/***************/
	CC.clear();
    for(int k=0; k< Q.size();k++)
	{		
		CC.push_back(Q[k]);
	}
	for (int n = 0; n < nvar; n++)
	{
	   for (int z=0;z<population.size();z++)
	   
          CC[0].x_var[n] += population[z].x_var[n];
		  CC[0].x_var[n] /= population.size();

	}
	for (int m=0;m<nobj;m++)
	{
        CC[0].y_obj[m]=0;
	}
	C1.clear();
	C1=CC;
	C2.clear();
	int size = 20;
	double stepsize = 1.0;
	
	//if (Q0.size()) stepsize = dist_vector(Q0, Q1);
    vector<double>  Cen(nvar, 0);
	//vector<CNSGA2Ind> predict;
	vector <double> Cen2(nvar, 0); 
	
	for (int n = 0; n < nvar; n++)
	{
		for (int i = 0; i < C0.size(); i++)
			Cen[n] += C0[i].x_var[n];
		Cen[n] /= C0.size();

		for (int i = 0; i < C1.size(); i++)
			Cen2[n] += C1[i].x_var[n];
		Cen2[n] /= C1.size();
	}
   for(int i=0; i<C1.size();i++)
	{
		/*for (int n = 0; n < nvar; n++)
		{*/
			C2.push_back(C1[i]);
		/*}*/
	}
	
	for (int i = 0; i < population.size(); i++)
	{
		if (C1.size())
			for (int n = 0; n < nvar; n++)
			{
				/*for(int j=0; j<nobj; j++)
			   { */ 
				double normd = dist_vector(Cen, Cen2);
				normd = normd>0 ? normd : 1.0e-6;
				
				population[i].x_var[n]=  fabs(population[i].x_var[n]+  stepsize*(Cen[n] - Cen2[n])*normd  + rnd_gaussian(&rnd_uni_init, 0, stepsize /2));/// normd
				if (population[i].x_var[n]<lowBound) population[i].x_var[n] = lowBound;
				if (population[i].x_var[n]>uppBound) population[i].x_var[n] = uppBound;
				population[i].rnd_init1(a);
				//int a=1;
				/*}*/
			}
			//int a=1;
			population[i].obj_eval1(a);
			//predict.push_back(Q2[i]);

		
	}
	/*************************/
int dd=1;

 char filenamechange2[1024];
 for(int gen=1; gen<=max_gen1; gen++)
{
   initial(a);
   rank_popu();
   eval_dens();
   sprintf(filenamechange2,"F:\\gen\\%fdynamic2_%d.txt",T, gen);
   ofstream filechange2(filenamechange2);
   for(int n=0; n<pops; n++)
  {
	
	//filex<<population[n].y_obj[0]<<"  "<<" "<<population[n].y_obj[1]<<"  "<<" "<<population[n].y_obj[2]<<endl;
	filechange2<<population[n].y_obj[0]<<"  "<<" "<<population[n].y_obj[1]<<endl;    

   }
   calc_distancetext();
}
  

	/***********/
	/*C0 = C1;
    C1 = C2;*/
	/**********/
	//Cen.clear();//xinjiade
	//Cen2.clear();//xinjiade
	//C0.clear();//xinjiade

	offspring.clear();
	int k=1;

}
void CNSGA2::change1(double T)//
{
   int a=T;
   int num=3;
   vector<CNSGA2Ind> newlist;
   newlist.clear();
	double *x = new double[pops];
    double *xx = new double[pops];
	//double *newlist = new double[pops];
	//int *idx = new int[pops];
/*********************************///
	for (int i = 0; i<pops; i++)
	{
		for (int j = i+1; j<pops; j++)
		{
			
			double miniture = min((population[i].y_obj[0]-population[j].y_obj[0]),(population[i].y_obj[1]-population[j].y_obj[1]));
			x[i] += -exp(-(miniture)/0.05);
			//idx[j] = j;	
		}

	}
	int kg=1;
	
    for (int k=0;k<num;k++)
	{
        initial(a);
		for (int i = 0; i<pops; i++)
	   {
			for (int j = i+1; j<pops; j++)
			{
				
				double minit = min((population[i].y_obj[0]-population[j].y_obj[0]),(population[i].y_obj[1]-population[j].y_obj[1]));
				xx[i] += -exp(-(minit)/0.05);
	
			}
			if(xx[i]>x[i])
			{
				newlist.push_back(population[i]);
				
			}
				
	    }
		   int c=1;
		  
		    

   
	}
	/**********************/

	char filenamechange1[1024];
   for(int gen=1; gen<=max_gen1; gen++)
  {
	initial(a);
    rank_popu();
    eval_dens();
	sprintf(filenamechange1,"F:\\gen\\%fdynamic1_%d.txt",T, gen);
    ofstream filechange1(filenamechange1);
   for(int n=0; n<pops; n++)
   {
	
	//filex<<population[n].y_obj[0]<<"  "<<" "<<population[n].y_obj[1]<<"  "<<" "<<population[n].y_obj[2]<<endl;
	filechange1<<population[n].y_obj[0]<<"  "<<" "<<population[n].y_obj[1]<<endl;    

    }
   calc_distancetext();
 }
   

	

	offspring.clear();
	newlist.clear();
	int sd=1;
	
	delete[] x;
	delete[] xx;
	//delete[] idx;
}
void CNSGA2::init_values()
{
  for (int s=0;s< STATES;s++)
    for (int a=0;a<ACTIONS;a++)
	qvalues[s][a] = 0.0;
  
  for (int s=0;s< STATES;s++)
    for (int a=0;a<ACTIONS;a++)
	reward[s][a] = 0.0;

}
void CNSGA2::select(double T,double et)
{
	
	double Tolerror = 0.003;
    double Tolerror1 = 0.001;
	double *probability=new double[3];
	int s=0;
	int m=0;
	int random1=0;//=RandomInt(0,2)
	double r=RandomDouble(0,1);
	double rewards[100];
	double rreward=0;
	double igdistance=0;
	double maxvalue,maxvalue1;
    maxvalue =-1.0; //1e+30
	//maxvalue1 = -1.0e+30;
	int id5,id6;
	double min,max;
    min = 1.0e+30, max = -1.0e+30;
	double min1,max1;
    min1 = 1.0e+30, max1 = -1.0e+30;
	double min2,max2;
    min2 = 1.0e+30, max2 = -1.0e+30;
	int id1,id2,id3,id4,id7,id8;
	if(et>=Tolerror)
   {
       s=2;
       for (int a=0;a<ACTIONS;a++)
	  {
          //maxvalue[s][a]=qvalues[s][a];
		  if ((maxvalue < qvalues[s][a])&&(!(qvalues[s][a])==0))//(maxvalue < qvalues[s][a])
		 {
			maxvalue = qvalues[s][a]; 
			id5 = a;
		 } 
		
	     probability[a]=exp(2*qvalues[s][a]/maxvalue)/(exp(2*qvalues[s][0]/maxvalue)+exp(2*qvalues[s][1]/maxvalue)+exp(2*qvalues[s][2]/maxvalue));
	   }
	   int p=1;

	   if((r>=0)&&((probability[0])>=r))
	  {      
		     random1=0;
			 change(T);
	   }
	  if((r>=(probability[0]))&&(r<=(probability[0]+probability[1])))
	  {      random1=1;
	 		 change1(T);
	  }
	  if((r>=(probability[0]+probability[1]))&&(r<=(probability[0]+probability[1]+probability[2])))
	  {
		     random1=2;
             change2(T);
	  }
      for(int n=0;n<pops;n++)
	 {
	   if (min>population[n].y_obj[0])
		{
			min = population[n].y_obj[0];
			id1 = n;
		}
		if (max < population[n].y_obj[0])
		{
			max = population[n].y_obj[0]; 
			id2 = n;
		}
		 if (min1>population[n].y_obj[1])
		{
			min1 = population[n].y_obj[1];
			id3 = n;
		}
		/*if (max1< population[n].y_obj[1])
		{
			max1 = population[n].y_obj[1]; 
			id4 = n;
		}*/
	    max1 = 1.1;
		if (min2>population[n].y_obj[2])
		{
			min2 = population[n].y_obj[2];
			id7 = n;
		}
		if (max2< population[n].y_obj[2])
		{
			max2 = population[n].y_obj[2]; 
			id8 = n;
		}
	 }
     for(int n=0;n<pops;n++)
	 {
       //rewards[n]= fabs(max-population[n].y_obj[0])*fabs(max1-population[n].y_obj[1])*fabs(max2-population[n].y_obj[2]);
	   rewards[n]= fabs(max-population[n].y_obj[0])*fabs(max1-population[n].y_obj[1]);
       //rewards=rewards/pops;
	 }
	 sort(rewards,rewards+pops);
	 rreward=rewards[pops-1];
	 igdistance=calc_distance();
     rreward=rreward+igdistance;
     qvalues[s][random1]=qvalues[s][random1]+aa*(rreward+rr*maxvalue-qvalues[s][random1]);
	 int kk=1;
   }

   if((et<Tolerror)&&(et>=Tolerror1))
   {
       s=1;
       for (int a=0;a<ACTIONS;a++)
	  {
          //maxvalue[s][a]=qvalues[s][a];
		  if ((maxvalue < qvalues[s][a])&&(!(qvalues[s][a])==0))
		 {
			maxvalue = qvalues[s][a]; 
			id5 = a;
		 }
		 
	     probability[a]=exp(2*qvalues[s][a]/maxvalue)/(exp(2*qvalues[s][0]/maxvalue)+exp(2*qvalues[s][1]/maxvalue)+exp(2*qvalues[s][2]/maxvalue));
	   }
	    int p=1;

	   if((r>=0)&&((probability[0])>=r))
	  {      
		     random1=0;
			 change(T);
	   }
	  if((r>=(probability[0]))&&(r<=(probability[0]+probability[1])))
	  {      random1=1;
	 		 change1(T);
	  }
	  if((r>=(probability[0]+probability[1]))&&(r<=(probability[0]+probability[1]+probability[2])))
	  {
		     random1=2;
             change2(T);
	  }
      for(int n=0;n<pops;n++)
	 {
	   if (min>population[n].y_obj[0])
		{
			min = population[n].y_obj[0];
			id1 = n;
		}
		if (max < population[n].y_obj[0])
		{
			max = population[n].y_obj[0]; 
			id2 = n;
		}
		 if (min1>population[n].y_obj[1])
		{
			min1 = population[n].y_obj[1];
			id3 = n;
		}
		if (max1< population[n].y_obj[1])
		{
			max1 = population[n].y_obj[1]; 
			id4 = n;
		}
		//max1 = 1.1;
		if (min2>population[n].y_obj[2])
		{
			min2 = population[n].y_obj[2];
			id7 = n;
		}
		if (max2< population[n].y_obj[2])
		{
			max2 = population[n].y_obj[2]; 
			id8 = n;
		}
	 }
    for(int n=0;n<pops;n++)
	 {
       //rewards[n]= fabs(max-population[n].y_obj[0])*fabs(max1-population[n].y_obj[1])*fabs(max2-population[n].y_obj[2]);
	   rewards[n]= fabs(max-population[n].y_obj[0])*fabs(max1-population[n].y_obj[1]);
       //rewards=rewards/pops;
	 }
	 sort(rewards,rewards+pops);
	 rreward=rewards[pops-1];
	 igdistance=calc_distance();
     rreward=rreward+igdistance;
     qvalues[s][random1]=qvalues[s][random1]+aa*(rreward+rr*maxvalue-qvalues[s][random1]);
	 int kk=1;
   }
   if((et<Tolerror1)&&(et>=0))
   {
       s=0;
       for (int a=0;a<ACTIONS;a++)
	  {
          //maxvalue[s][a]=qvalues[s][a];
		  if ((maxvalue < qvalues[s][a])&&(!(qvalues[s][a])==0))//(maxvalue < qvalues[s][a])
		 {
			maxvalue = qvalues[s][a]; 
			id5 = a;
		 } 
		
	     probability[a]=exp(2*qvalues[s][a]/maxvalue)/(exp(2*qvalues[s][0]/maxvalue)+exp(2*qvalues[s][1]/maxvalue)+exp(2*qvalues[s][2]/maxvalue));
	   }
		    int p=1;

	  if((r>=0)&&((probability[0])>=r))
	  {      
		     random1=0;
			 change(T);
	   }
	  if((r>=(probability[0]))&&(r<=(probability[0]+probability[1])))
	  {      random1=1;
	 		 change1(T);
	  }
	  if((r>=(probability[0]+probability[1]))&&(r<=(probability[0]+probability[1]+probability[2])))
	  {
		     random1=2;
             change2(T);
	  }
      for(int n=0;n<pops;n++)
	 {
	   if (min>population[n].y_obj[0])
		{
			min = population[n].y_obj[0];
			id1 = n;
		}
		if (max < population[n].y_obj[0])
		{
			max = population[n].y_obj[0]; 
			id2 = n;
		}
		 if (min1>population[n].y_obj[1])
		{
			min1 = population[n].y_obj[1];
			id3 = n;
		}
		/*if (max1< population[n].y_obj[1])
		{
			max1 = population[n].y_obj[1]; 
			id4 = n;
		}*/
		 max1 = 1.1;
		if (min2>population[n].y_obj[2])
		{
			min2 = population[n].y_obj[2];
			id7 = n;
		}
		if (max2< population[n].y_obj[2])
		{
			max2 = population[n].y_obj[2]; 
			id8 = n;
		}
	 }
     for(int n=0;n<pops;n++)
	 {
       //rewards[n]= fabs(max-population[n].y_obj[0])*fabs(max1-population[n].y_obj[1])*fabs(max2-population[n].y_obj[2]);
	   rewards[n]= fabs(max-population[n].y_obj[0])*fabs(max1-population[n].y_obj[1]);
       //rewards=rewards/pops;
	 }
	 sort(rewards,rewards+pops);
	 rreward=rewards[pops-1];
	 igdistance=calc_distance();
     rreward=rreward+igdistance;
     qvalues[s][random1]=qvalues[s][random1]+aa*(rreward+rr*maxvalue-qvalues[s][random1]);
	 int kk=1;
   }
   
	  experts.push_back(s);
   
  
	   experta.push_back(random1);
	   reward_list.push_back(rreward);
	int k=1;
	
}
void CNSGA2::selecttest(double T,double et)
{
	double Tolerror = 0.003;
    double Tolerror1 = 0.001;
	double *probability=new double[3];
	int s=0;
	int m=0;
	int random1=0;//=RandomInt(0,2)
	double r=RandomDouble(0,1);
	double rewards[100];
	double rreward=0;
	double igdistance=0;
	double maxvalue,maxvalue1;
    maxvalue =-1.0; //1e+30
	//maxvalue1 = -1.0e+30;
	int id5,id6;
	double min,max;
    min = 1.0e+30, max = -1.0e+30;
	double min1,max1;
    min1 = 1.0e+30, max1 = -1.0e+30;
	double min2,max2;
    min2 = 1.0e+30, max2 = -1.0e+30;
	int id1,id2,id3,id4,id7,id8;
	if(et>=Tolerror)
   {
       s=2;
       for (int a=0;a<ACTIONS;a++)
	  {
          //maxvalue[s][a]=qvalues[s][a];
		  if ((maxvalue < qvalues[s][a])&&(!(qvalues[s][a])==0))//(maxvalue < qvalues[s][a])
		 {
			maxvalue = qvalues[s][a]; 
			id5 = a;
		 } 
		
	     probability[a]=exp(2*qvalues[s][a]/maxvalue)/(exp(2*qvalues[s][0]/maxvalue)+exp(2*qvalues[s][1]/maxvalue)+exp(2*qvalues[s][2]/maxvalue));
	   }
	   int p=1;

	   if((r>=0)&&((probability[0])>=r))
	  {      
		     random1=0;
			 change(T);
	   }
	  if((r>=(probability[0]))&&(r<=(probability[0]+probability[1])))
	  {      random1=1;
	 		 change1(T);
	  }
	  if((r>=(probability[0]+probability[1]))&&(r<=(probability[0]+probability[1]+probability[2])))
	  {
		     random1=2;
             change2(T);//change2(T)
	  }
  //    for(int n=0;n<pops;n++)
	 //{
	 //  if (min>population[n].y_obj[0])
		//{
		//	min = population[n].y_obj[0];
		//	id1 = n;
		//}
		//if (max < population[n].y_obj[0])
		//{
		//	max = population[n].y_obj[0]; 
		//	id2 = n;
		//}
		// if (min1>population[n].y_obj[1])
		//{
		//	min1 = population[n].y_obj[1];
		//	id3 = n;
		//}
		///*if (max1< population[n].y_obj[1])
		//{
		//	max1 = population[n].y_obj[1]; 
		//	id4 = n;
		//}*/
	 //   max1 = 1.1;
		//if (min2>population[n].y_obj[2])
		//{
		//	min2 = population[n].y_obj[2];
		//	id7 = n;
		//}
		//if (max2< population[n].y_obj[2])
		//{
		//	max2 = population[n].y_obj[2]; 
		//	id8 = n;
		//}
	 //}
  //   for(int n=0;n<pops;n++)
	 //{
  //     //rewards[n]= fabs(max-population[n].y_obj[0])*fabs(max1-population[n].y_obj[1])*fabs(max2-population[n].y_obj[2]);
	 //  rewards[n]= fabs(max-population[n].y_obj[0])*fabs(max1-population[n].y_obj[1]);
  //     //rewards=rewards/pops;
	 //}
     rreward=calc_hv();
	 //sort(rewards,rewards+pops);
	 //rreward=rewards[pops-1];
	 igdistance=calc_distance();
     rreward=rreward+igdistance;
     qvalues[s][random1]=qvalues[s][random1]+aa*(rreward+rr*maxvalue-qvalues[s][random1]);
	 int kk=1;
   }

   if((et<Tolerror)&&(et>=Tolerror1))
   {
       s=1;
       for (int a=0;a<ACTIONS;a++)
	  {
          //maxvalue[s][a]=qvalues[s][a];
		  if ((maxvalue < qvalues[s][a])&&(!(qvalues[s][a])==0))
		 {
			maxvalue = qvalues[s][a]; 
			id5 = a;
		 }
		 
	     probability[a]=exp(2*qvalues[s][a]/maxvalue)/(exp(2*qvalues[s][0]/maxvalue)+exp(2*qvalues[s][1]/maxvalue)+exp(2*qvalues[s][2]/maxvalue));
	   }
	    int p=1;

	   if((r>=0)&&((probability[0])>=r))
	  {      
		     random1=0;
			 change(T);
	   }
	  if((r>=(probability[0]))&&(r<=(probability[0]+probability[1])))
	  {      random1=1;
	 		 change1(T);
	  }
	  if((r>=(probability[0]+probability[1]))&&(r<=(probability[0]+probability[1]+probability[2])))
	  {
		     random1=2;
             change2(T);//change2(T)
	  }
  //    for(int n=0;n<pops;n++)
	 //{
	 //  if (min>population[n].y_obj[0])
		//{
		//	min = population[n].y_obj[0];
		//	id1 = n;
		//}
		//if (max < population[n].y_obj[0])
		//{
		//	max = population[n].y_obj[0]; 
		//	id2 = n;
		//}
		// if (min1>population[n].y_obj[1])
		//{
		//	min1 = population[n].y_obj[1];
		//	id3 = n;
		//}
		//if (max1< population[n].y_obj[1])
		//{
		//	max1 = population[n].y_obj[1]; 
		//	id4 = n;
		//}
		////max1 = 1.1;
		//if (min2>population[n].y_obj[2])
		//{
		//	min2 = population[n].y_obj[2];
		//	id7 = n;
		//}
		//if (max2< population[n].y_obj[2])
		//{
		//	max2 = population[n].y_obj[2]; 
		//	id8 = n;
		//}
	 //}
  //  for(int n=0;n<pops;n++)
	 //{
  //     //rewards[n]= fabs(max-population[n].y_obj[0])*fabs(max1-population[n].y_obj[1])*fabs(max2-population[n].y_obj[2]);
	 //  rewards[n]= fabs(max-population[n].y_obj[0])*fabs(max1-population[n].y_obj[1]);
  //     //rewards=rewards/pops;
	 //}
	 //sort(rewards,rewards+pops);
	 //rreward=rewards[pops-1];
	 rreward=calc_hv();
	 igdistance=calc_distance();
     rreward=rreward+igdistance;
     qvalues[s][random1]=qvalues[s][random1]+aa*(rreward+rr*maxvalue-qvalues[s][random1]);
	 int kk=1;
   }
   if((et<Tolerror1)&&(et>=0))
   {
       s=0;
       for (int a=0;a<ACTIONS;a++)
	  {
          //maxvalue[s][a]=qvalues[s][a];
		  if ((maxvalue < qvalues[s][a])&&(!(qvalues[s][a])==0))//(maxvalue < qvalues[s][a])
		 {
			maxvalue = qvalues[s][a]; 
			id5 = a;
		 } 
		
	     probability[a]=exp(2*qvalues[s][a]/maxvalue)/(exp(2*qvalues[s][0]/maxvalue)+exp(2*qvalues[s][1]/maxvalue)+exp(2*qvalues[s][2]/maxvalue));
	   }
		    int p=1;

	  if((r>=0)&&((probability[0])>=r))
	  {      
		     random1=0;
			 change(T);
	   }
	  if((r>=(probability[0]))&&(r<=(probability[0]+probability[1])))
	  {      random1=1;
	 		 change1(T);
	  }
	  if((r>=(probability[0]+probability[1]))&&(r<=(probability[0]+probability[1]+probability[2])))
	  {
		     random1=2;
             change2(T);//change2(T)
	  }
  //    for(int n=0;n<pops;n++)
	 //{
	 //  if (min>population[n].y_obj[0])
		//{
		//	min = population[n].y_obj[0];
		//	id1 = n;
		//}
		//if (max < population[n].y_obj[0])
		//{
		//	max = population[n].y_obj[0]; 
		//	id2 = n;
		//}
		// if (min1>population[n].y_obj[1])
		//{
		//	min1 = population[n].y_obj[1];
		//	id3 = n;
		//}
		///*if (max1< population[n].y_obj[1])
		//{
		//	max1 = population[n].y_obj[1]; 
		//	id4 = n;
		//}*/
		// max1 = 1.1;
		//if (min2>population[n].y_obj[2])
		//{
		//	min2 = population[n].y_obj[2];
		//	id7 = n;
		//}
		//if (max2< population[n].y_obj[2])
		//{
		//	max2 = population[n].y_obj[2]; 
		//	id8 = n;
		//}
	 //}
  //   for(int n=0;n<pops;n++)
	 //{
  //     //rewards[n]= fabs(max-population[n].y_obj[0])*fabs(max1-population[n].y_obj[1])*fabs(max2-population[n].y_obj[2]);
	 //  rewards[n]= fabs(max-population[n].y_obj[0])*fabs(max1-population[n].y_obj[1]);
  //     //rewards=rewards/pops;
	 //}
	 //sort(rewards,rewards+pops);
	 //rreward=rewards[pops-1];
     rreward=calc_hv();
	 igdistance=calc_distance();
     rreward=rreward+igdistance;
     qvalues[s][random1]=qvalues[s][random1]+aa*(rreward+rr*maxvalue-qvalues[s][random1]);
	 int kk=1;
   }
   
	  //experts.push_back(s);
   
  
	   //experta.push_back(random1);
	   reward_list.push_back(rreward);
	int k=1;
  
	
}
void CNSGA2::detectchange(double T)
{
   	vector <double> oldobj(nobj, 0.0);
	double min,max;
    min = 1.0e+30, max = -1.0e+30;
	double min1,max1;
    min1 = 1.0e+30, max1 = -1.0e+30;
	double min2,max2;
    min2 = 1.0e+30, max2 = -1.0e+30;
	int id1,id2,id3,id4,id7,id8;
	double et;
	et=0.0;
	for(int n=0;n<pops;n++)
	{
	   for (int i = 0; i < nobj; i++)
	   {oldobj[i] = population[n].y_obj[i];}
	   population[n].obj_eval1(T);
 
	   if (min>population[n].y_obj[0])
		{
			min = population[n].y_obj[0];
			id1 = n;
		}
		if (max < population[n].y_obj[0])
		{
			max = population[n].y_obj[0]; 
			id2 = n;
		}
		 if (min1>population[n].y_obj[1])
		{
			min1 = population[n].y_obj[1];
			id3 = n;
		}
		if (max1< population[n].y_obj[1])
		{
			max1 = population[n].y_obj[1]; 
			id4 = n;
		}
		if (min2>population[n].y_obj[2])
		{
			min2 = population[n].y_obj[2];
			id7 = n;
		}
		if (max2< population[n].y_obj[2])
		{
			max2 = population[n].y_obj[2]; 
			id8 = n;
		}
	}
	double temp=sqrt(pow((max-min),2)+pow((max1-min1),2)+pow((max2-min2),2));
	
    double T1=T;
	for(int n=0;n<100;n++)
	{
	   for (int i = 0; i < nobj; i++)
	  {
         et+=fabs((population[n].y_obj[i] - oldobj[i])/temp);
		 et=et/100;		 
	  }
	}
    selecttest(T1,et);
	

}
void CNSGA2::modeltraining()
{
	int traintrials=1;
	double expectation_feature=0;
	double expect_expert=0;
	while(traintrials>0)
	{
       expectation_feature=execute_RL();
	   expect_expert=expert_policy();
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		/*if(traintrials==1)
	  {
        expectation_feature= random_pick_policy();
		expect_expert=expert_policy();
	  else
	  {

	  }
	   */
	 
      traintrials++; 
     
	}


}
double CNSGA2::execute_RL()
{
	  double sum_reward=0;
	  for(int TT=2;TT<22;TT++)//22 
	  {
			double t=1.0/10*(TT-1);
			
			detectchange(t);
			//change2(t);
			for(int gen=1; gen<=max_gen1; gen++)
			{
			 
			   if((TT==21)&&(gen%max_gen1==0))
				{ 
				   for(int i=0;i<reward_list.size();i++)
				   {
                    sum_reward += reward_list[i];
				   }
					
				   			
				 }

			 }
	
	    }
	
	  int rr=1;
	  return sum_reward;
	  reward_list.clear();

}
double CNSGA2::expert_policy()
{
   double exreward[20];
   ifstream inFile3;
   int count4;
   double expert_reward=0;
    inFile3.open("F:/IRLRESULT/irl-reward.txt");
 
    for ( count4=0; count4<2000;count4++)    
    {
        inFile3>>exreward[count4];
    }
    inFile3.close();
	for(int ka=0;ka<20;ka++)
	{
        expert_reward+=exreward[ka];
	}
    return expert_reward;
}
double CNSGA2::random_pick_policy()
{
    int nState[200];
    int nAction[200];
	double Qvalue[9];
	double ereward[200];
    ifstream inFile,inFile1,inFile2;
    int count,count1,count2; 
	double expect=0;
	double expect_reward=0;
    
 
	inFile.open("F:/randompickpolicy.txt");
 
    for ( count=0; count<200;count++)     
    {
        inFile>>nState[count]>>nAction[count];
    }
    inFile.close();

	//inFile1.open("F:/irl101908-qvalue.txt");
 //
 //   for ( count1=0; count1<9;count1++)   
 //   {
 //       inFile1>>Qvalue[count1];
 //   }
 //   inFile1.close();
    inFile2.open("F:/irl-reward.txt");
 
    for ( count2=0; count2<200;count2++)   
    {
        inFile2>>ereward[count2];
    }
    inFile2.close();
	/*for(int k=0;k<9;k++)
	{
        expect+=Qvalue[k];
	}*/
		for(int kk=0;kk<200;kk++)
	{
        expect_reward+=ereward[kk];
	}
	
	//��ר����������������ľ��룬��reward function��ϵ��w
	//if minimum 
	//use q learning output the policy
	//return expect;
	return expect_reward;
    

}
vector<double> CNSGA2::execute(int run)
{

	
/****************************************************************************/
	seed = (seed + 23)%1377;					
	rnd_uni_init = -(long)seed;	
	vector<double> gd;
	init_values();

	
   
	char filename[1024]; 
	
    nfes    = 0; 	 
/************************************************/
	
/************************************************/

	// first generation
	int gen   = 1; //��ʱ��T=0
	int t1=0;
	
   for(int n=0;n<pops;n++)
   {
	CNSGA2Ind ind;
	ind.rnd_init1(t1);	
	population.push_back(ind);
	nfes++;
   }
    //calc_distance();
	gd.push_back(0);  gd.push_back(distance);
    
   double Start_time,time_difference;

	Start_time =(float)clock()/(CLK_TCK);
	
	for(gen=2; gen<=50; gen++)//max_gen
	{
	    initial(t1);
		rank_popu();
		//eval_dens1();
		eval_dens();
		
		int dd = int(max_gen/25.0);
        if(gen==50)//gen%max_gen==0
		{
	   	   for(int n=0; n<pops; n++)
	       {
		
		     cout<<population[n].y_obj[0]<<"  "<<" "<<population[n].y_obj[1]<<"  "<<" "<<population[n].y_obj[2]<<endl;
		      //cout<<population[n].y_obj[0]<<"  "<<" "<<population[n].y_obj[1]<<endl;
			 

	        }
		    
		   //hv();
		}
        calc_distancetext();
		
		sprintf(filename,"F:\\gen\\%d.txt",gen);
		ofstream filestatic(filename);
        for(int n=0; n<pops; n++)
		{
			
			//filex<<population[n].y_obj[0]<<"  "<<" "<<population[n].y_obj[1]<<"  "<<" "<<population[n].y_obj[2]<<endl;
			filestatic<<population[n].y_obj[0]<<"  "<<" "<<population[n].y_obj[1]<<endl;    

		 }
		int a=1;

	}

	//char filenamex[100] = "F:/rldata/11";
	//char *namex = filenamex; 
	//strcpy(namex, "F:/rldata/11.txt");
	//ofstream filex(namex);//����txt
	//for(int n=0; n<pops; n++)
	//{
	//	
	//	filex<<population[n].y_obj[0]<<"  "<<" "<<population[n].y_obj[1]<<"  "<<" "<<population[n].y_obj[2]<<endl;
	//	//filex<<population[n].y_obj[0]<<"  "<<" "<<population[n].y_obj[1]<<endl;    

	// }
 //   filex<<"******************************"<<endl;

   /*************************************************/
	

	/***********************************************/

    int group=10;//�ɱ仯
    
	double Start_time1,time_difference1;
	calc_distance();
    calc_hv();
	
	
	/******************************/
    Start_time1 =(float)clock()/(CLK_TCK);
	for(int TT=2;TT<32;TT++)//22 
	{
		double t=1.0/10*(TT-1);
		
        detectchange(t);
		//change2(t);
		
		   if(TT==21)
			{ 
			   calc_distance();
				//preserveigd();
			  //calc_hv();
			   preservehv();
			   			
		   }
	       
			if(TT==21)//21
			{      
				char filename[100] = "F:/rldata/1-30";
				char *name = filename; 
				strcpy(name, "F:/rldata/1-30.txt");
				ofstream file(name);//����txt
				for(int n=0; n<pops; n++)
				{
					
					file<<population[n].y_obj[0]<<"  "<<" "<<population[n].y_obj[1]<<"  "<<" "<<population[n].y_obj[2]<<endl;
					//file<<population[n].y_obj[0]<<"  "<<" "<<population[n].y_obj[1]<<endl;    

				 }
                file<<"******************************"<<endl;
				for(int nn=0; nn<experts.size(); nn++)
			   {
                  //cout<<experts[nn]<<"  "<<" "<<experta[nn]<<endl;
				  file<<experts[nn]<<"  "<<" "<<experta[nn]<<endl;
			   }
				 file<<"******************************"<<endl;

				char filenamear[100] = "F:/rldata/1-30";
				char *namear = filenamear; 
					strcpy(namear, "F:/rldata/1-30.txt");
				ofstream filear(namear);//����txt
				for(int n=0; n<population.size(); n++)//ps
				{
					
					filear<<population[n].y_obj[0]<<"  "<<" "<<population[n].y_obj[1]<<"  "<<" "<<population[n].y_obj[2]<<endl;
					//filear<<population[n].y_obj[0]<<"  "<<" "<<population[n].y_obj[1]<<endl;  //ps  

				 }
                filear<<"******************************"<<endl;
				

	             
			 }
			if(TT==21)
			{      
				
				for(int n=0; n<pops; n++)
				{
					for(int k=0;k<nobj;k++)
					{
						cout<<population[n].y_obj[k]<<"  ";
						cout<<"\n";
					 }
	
				 }
					             
			 }
			/*if((TT==21)&&(gen%max_gen1==0))
			{
				for(int nn=0; nn<experts.size(); nn++)
			   {
                  cout<<experts[nn]<<"  "<<" "<<experta[nn]<<endl;
				  file<<experts[nn]<<"  "<<" "<<experta[nn]<<endl;
			   }
				
			}*/
			if(TT==21)
			{ 
			  
               cout<<"****************"<<endl;
			}
				
	
	    

        time_difference1=(float)clock()/(CLK_TCK)-Start_time1;
        time_difference1=time_difference1/20;

	
	
	}
	time_difference=(float)clock()/(CLK_TCK)-Start_time;
/******************************************************************************************/

	char filenametextigd[100] = "F:/gen/1-30-igd";
	char *nametextigd = filenametextigd; 
	strcpy(nametextigd, "F:/gen/1-30-igd.txt");
	ofstream filetextigd(nametextigd);//����txt
	for(int pp=0;pp<igdtext.size();pp++)
	{
       filetextigd<<igdtext[pp]<<endl;
	}
	//filetextigd<<dis<<  endl;
/**********************************************************/

	population.clear();
	offspring.clear();
	ps.clear();
	reward_list.clear();
	//std::cout<<" Outcome of the "<<run<<"th run:  distance= "<<distance<<" nfes = "<<nfes<<endl;
	std::cout<<"one generation time:"<<time_difference1<<"total time:"<<time_difference<<endl;
	
	return gd;
/**********************************/

}

void CNSGA2::save_front(char saveFilename[1024])
{
    std::fstream fout;
	fout.open(saveFilename,std::ios::out);
	for(int n=0; n<pops; n++)
	{
		for(int k=0;k<nobj;k++)
			fout<<population[n].y_obj[k]<<"  ";
		fout<<"\n";
	}
	fout.close();
}

void CNSGA2::save_ps(char saveFilename[1024])
{
    std::fstream fout;
	fout.open(saveFilename,std::ios::out);
	for(int n=0; n<pops; n++)
	{
		for(int k=0;k<nvar;k++)
			fout<<population[n].x_var[k]<<"  ";
		fout<<"\n";
	}
	fout.close();
}


double CNSGA2::calc_distance()
{
    double dis = 0;
	
	double psfront1[1000];
    double psfront2[1000];
	//double psfront3[1000];
   ifstream inFileps;
   int countps;
   //double expert_reward=0;
    inFileps.open("F:/POF/benchmark11.txt");
 
    for ( countps=0; countps<1000;countps++)     
    {
        //inFileps>>psfront1[countps]>>psfront2[countps]>>psfront3[countps];
		inFileps>>psfront1[countps]>>psfront2[countps];
  
    }
    inFileps.close();
	/********2��Ŀ��**3��Ŀ��******/
	for(int i=0; i<1000; i++)
	{
	    double min_d = 1.0e+10;
		for(int j=0; j<population.size(); j++)
		{
			double sum=0;
            sum =(psfront1[i]-population[j].y_obj[0])*(psfront1[i]-population[j].y_obj[0])+(psfront2[i]-population[j].y_obj[1])*(psfront2[i]-population[j].y_obj[1]);//population
			//sum =(psfront1[i]-population[j].y_obj[0])*(psfront1[i]-population[j].y_obj[0])+(psfront2[i]-population[j].y_obj[1])*(psfront2[i]-population[j].y_obj[1])+(psfront3[i]-population[j].y_obj[2])*(psfront3[i]-population[j].y_obj[2]);
	        double d=  sqrt(sum);
			if(d<min_d)  min_d = d;
		}
		dis+= min_d;
	}
	/*********************/

	
	dis=dis/1000;
	int l=1;
    char filenameigd[100] = "F:/rldata/11-igd";
	char *nameigd = filenameigd; 
	strcpy(nameigd, "F:/rldata/11-igd.txt");
	ofstream fileigd(nameigd);
    
	fileigd<<dis<<  endl;
				  				  
	return dis;
	

}

void CNSGA2::preserveigd()
{
    double dis = 0;

	int x=population.size();
	ps1.clear();
	ps11.clear();

	double *density = new double[x];
	int    *idx     = new int[x];
	
 	
	for(int i=0; i<x; i++){
		idx[i]     = i;
		density[i] = 0;
	}

	int    *idd     = new int[x];
	double *obj     = new double[x];//nobj
	/*for(int j=0; j<nobj; j++){	*/	    			
		for(int i=0; i<x; i++){
		    idd[i] = i;
			//obj[i] = ps[i].y_obj[0];
			obj[i] = population[i].y_obj[0];//j
		}
		minfastsort(obj,idd,x,x);
    
/***************/
    for(int i=0;i<x;i++)
	{
		
		ps11.push_back(population[idd[i]]);
	}
	for(int kk=0; kk<ps11.size();kk++)
	{
	
		if(ps11[kk].y_obj[0]<=1.4)
		{
			if(ps11[kk].y_obj[1]<=1.4)
			{
				if(ps11[kk].y_obj[2]<=1.4)
				{
                     ps1.push_back(ps11[kk]);
				}
			}
			
		}
		
	}
/****************/


    delete [] idd;
	delete [] obj;
	
	double psfront1[1000];
    double psfront2[1000];
	double psfront3[1000];
   ifstream inFileps;
   int countps;
   //double expert_reward=0;
    inFileps.open("F:/POF/benchmark4.txt");
 
    for ( countps=0; countps<1000;countps++)    
    {
        inFileps>>psfront1[countps]>>psfront2[countps]>>psfront3[countps];
		//inFileps>>psfront1[countps]>>psfront2[countps];
  
    }
    inFileps.close();
	/********2��Ŀ��**3��Ŀ��******/
	for(int i=0; i<1000; i++)
	{
	    double min_d = 1.0e+10;
		for(int j=0; j<ps1.size(); j++)
		{
			double sum=0;
            //sum =(psfront1[i]-population[j].y_obj[0])*(psfront1[i]-population[j].y_obj[0])+(psfront2[i]-population[j].y_obj[1])*(psfront2[i]-population[j].y_obj[1]);//population
			sum =(psfront1[i]-ps1[j].y_obj[0])*(psfront1[i]-ps1[j].y_obj[0])+(psfront2[i]-ps1[j].y_obj[1])*(psfront2[i]-ps1[j].y_obj[1])+(psfront3[i]-ps1[j].y_obj[2])*(psfront3[i]-ps1[j].y_obj[2]);
	        double d=  sqrt(sum);
			if(d<min_d)  min_d = d;
		}
		dis+= min_d;
	}
	/*********************/

	
	dis=dis/1000;
	int l=1;
    char filenameigd[100] = "F:/rldata/4-igd";
	char *nameigd = filenameigd; 
	strcpy(nameigd, "F:/rldata/4-igd.txt");
	ofstream fileigd(nameigd);//����txt
    
	fileigd<<dis<<  endl;
	

}
double CNSGA2::calc_distancetext()
{
	 double dis = 0;
	
	
	double psfront1[1000];
    double psfront2[1000];
	double psfront3[1000];
   ifstream inFileps;
   int countps;
   //double expert_reward=0;
    inFileps.open("F:/POF/benchmark1.txt");
 
    for ( countps=0; countps<1000;countps++)   
    {
        inFileps>>psfront1[countps]>>psfront2[countps]>>psfront3[countps];
		//inFileps>>psfront1[countps]>>psfront2[countps];
  
    }
    inFileps.close();

	
	/********2��Ŀ��**3��Ŀ��******/
	for(int i=0; i<1000; i++)
	{
	    double min_d = 1.0e+10;
		for(int j=0; j<population.size(); j++)
		{
			double sum=0;
            //sum =(psfront1[i]-population[j].y_obj[0])*(psfront1[i]-population[j].y_obj[0])+(psfront2[i]-population[j].y_obj[1])*(psfront2[i]-population[j].y_obj[1]);//population
			sum =(psfront1[i]-population[j].y_obj[0])*(psfront1[i]-population[j].y_obj[0])+(psfront2[i]-population[j].y_obj[1])*(psfront2[i]-population[j].y_obj[1])+(psfront3[i]-population[j].y_obj[2])*(psfront3[i]-population[j].y_obj[2]);
	        double d=  sqrt(sum);
			if(d<min_d)  min_d = d;
		}
		dis+= min_d;
	}
	/*********************/

	
	dis=dis/1000;
	int l=1;
    
	igdtext.push_back(dis);
	
				  				  
	return dis;
}

#endif

